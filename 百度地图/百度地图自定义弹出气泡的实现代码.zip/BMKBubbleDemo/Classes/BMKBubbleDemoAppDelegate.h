//
//  BMKBubbleDemoAppDelegate.h
//  BMKBubbleDemo
//
//  Created by kingyee on 12-6-8.
//  Copyright 2012 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BMKBubbleDemoViewController;
@class BMKMapManager;

@interface BMKBubbleDemoAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    BMKBubbleDemoViewController *viewController;
    BMKMapManager* _mapManager;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet BMKBubbleDemoViewController *viewController;

@end

