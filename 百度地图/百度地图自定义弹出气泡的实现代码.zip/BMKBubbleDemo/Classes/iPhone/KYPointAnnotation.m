//
//  KYPointAnnotation.m
//  DrugRef
//
//  Created by chen xin on 12-6-6.
//  Copyright (c) 2012年 Kingyee. All rights reserved.
//

#import "KYPointAnnotation.h"

@implementation KYPointAnnotation

@synthesize tag =_tag;

@end
