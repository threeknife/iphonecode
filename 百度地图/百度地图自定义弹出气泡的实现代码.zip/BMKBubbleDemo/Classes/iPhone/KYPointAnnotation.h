//
//  KYPointAnnotation.h
//  DrugRef
//
//  Created by chen xin on 12-6-6.
//  Copyright (c) 2012年 Kingyee. All rights reserved.
//

#import "BMKPointAnnotation.h"

@interface KYPointAnnotation : BMKPointAnnotation {
    NSUInteger _tag;
}

@property NSUInteger tag;

@end
