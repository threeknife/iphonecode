//
//  BMKBubbleDemoViewController.h
//  BMKBubbleDemo
//
//  Created by kingyee on 12-6-8.
//  Copyright 2012 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KYBubbleView.h"

@interface BMKBubbleDemoViewController : UIViewController  <BMKMapViewDelegate, BMKSearchDelegate> {
	BMKMapView* _mapView;
    BMKSearch* _search;
    KYBubbleView *bubbleView;
    BMKAnnotationView *selectedAV;
    NSMutableArray *dataArray;
}

- (void)showBubble:(BOOL)show;
-(void)cleanMap;

@end

